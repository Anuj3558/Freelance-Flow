import { useState, useEffect } from "react"
import { Line, Bar } from "react-chartjs-2"
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js"
import Cookies from "js-cookie"

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title, Tooltip, Legend)

interface DashboardStats {
  totalClients: number
  activeClients: number
  totalRevenue: number
  totalExpenses: number
  activeProjects: number
  completedProjects: number
}

interface Milestone {
  _id: string
  id?: string
  name: string
  description: string
  percentage: number
  amount: number
  dueDate: string
  status: "Pending" | "Achieved" | "Overdue"
  projectId: string
  clientId: string
  estimateId?: string
  isAchieved?: boolean
  achievedDate?: string
}

interface ProjectWithMilestones {
  _id: string
  id?: string
  name: string
  description: string
  clientName: string
  clientId: string
  status: string
  totalAmount: number
  startDate: string
  endDate: string
  milestones: Milestone[]
  estimateName?: string
  createdAt: string
}

interface RevenueData {
  month: string
  revenue: number
  expenses: number
}

interface ExpenseBreakdown {
  category: string
  amount: number
}

export default function Dashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    totalClients: 0,
    activeClients: 0,
    totalRevenue: 0,
    totalExpenses: 0,
    activeProjects: 0,
    completedProjects: 0,
  })

  const [projects, setProjects] = useState<ProjectWithMilestones[]>([])
  const [selectedProject, setSelectedProject] = useState<ProjectWithMilestones | null>(null)
  const [showMilestones, setShowMilestones] = useState(false)
  const [loading, setLoading] = useState(true)
  const [loadingMilestones, setLoadingMilestones] = useState(false)
  const [updatingMilestone, setUpdatingMilestone] = useState<string | null>(null)
  const [revenueData, setRevenueData] = useState<RevenueData[]>([])
  const [expenseData, setExpenseData] = useState<ExpenseBreakdown[]>([])

  // API URLs
  const API_URL = "http://localhost:5000/api"
  const ANALYTICS_API_URL = `${API_URL}/analytics`
  const MILESTONES_API_URL = `${API_URL}/milestones`

  // Get JWT token from cookies
  const getAuthToken = () => {
    const token = Cookies.get("jwt_token")
    if (!token) {
      console.error("Authentication Error: No JWT token found")
      return null
    }
    return token
  }

  // Authorized fetch wrapper
  const authFetch = async (url: string, options: RequestInit = {}) => {
    const token = getAuthToken()
    if (!token) {
      throw new Error("No authentication token")
    }

    try {
      const response = await fetch(url, {
        ...options,
        headers: {
          ...options.headers,
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      })

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        throw new Error(errorData.message || `HTTP ${response.status}: ${response.statusText}`)
      }
      return await response.json()
    } catch (error) {
      if (error instanceof TypeError && error.message.includes('fetch')) {
        throw new Error("Network error: Unable to connect to server")
      }
      throw error
    }
  }

  // Fetch dashboard analytics
  const fetchDashboardAnalytics = async () => {
    try {
      const [statsResponse, revenueResponse, expensesResponse] = await Promise.all([
        authFetch(`${ANALYTICS_API_URL}/dashboard-stats`),
        authFetch(`${ANALYTICS_API_URL}/revenue-over-time`),
        authFetch(`${ANALYTICS_API_URL}/expense-breakdown`)
      ])

      if (statsResponse.success) {
        setStats(statsResponse.data)
      }

      if (revenueResponse.success) {
        setRevenueData(revenueResponse.data)
      }

      if (expensesResponse.success) {
        setExpenseData(expensesResponse.data)
      }
    } catch (error) {
      console.error("Error fetching analytics:", error)
      // Fallback to default data if backend is not available
      setRevenueData([
        { month: "Jan", revenue: 12000, expenses: 800 },
        { month: "Feb", revenue: 15000, expenses: 900 },
        { month: "Mar", revenue: 8000, expenses: 700 },
        { month: "Apr", revenue: 18000, expenses: 1000 },
        { month: "May", revenue: 22000, expenses: 1200 },
        { month: "Jun", revenue: 25000, expenses: 1100 },
      ])
      setExpenseData([
        { category: "Software", amount: 800 },
        { category: "Tools", amount: 400 },
        { category: "Marketing", amount: 300 },
        { category: "Office", amount: 500 },
        { category: "Other", amount: 200 },
      ])
    }
  }

  // Fetch projects with milestones
  const fetchProjectsWithMilestones = async () => {
    try {
      const response = await authFetch(`${MILESTONES_API_URL}/projects-with-milestones`)
      if (response.success) {
        const currentDate = new Date()
        
        // Filter projects where current date is between first milestone start date and last milestone end date
        const activeProjects = response.data.filter((project: ProjectWithMilestones) => {
          if (!project.milestones || project.milestones.length === 0) return false
          
          const sortedMilestones = project.milestones.sort((a, b) => 
            new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
          )
          
          const firstMilestoneDate = new Date(sortedMilestones[0].dueDate)
          const lastMilestoneDate = new Date(sortedMilestones[sortedMilestones.length - 1].dueDate)
          
          return currentDate >= firstMilestoneDate && currentDate <= lastMilestoneDate
        })

        setProjects(activeProjects)
      }
    } catch (error) {
      console.error("Error fetching projects with milestones:", error)
      setProjects([])
    }
  }

  // Mark milestone as achieved
  const markMilestoneAsAchieved = async (milestoneId: string) => {
    setUpdatingMilestone(milestoneId)
    try {
      const response = await authFetch(`${MILESTONES_API_URL}/achieve-milestone/${milestoneId}`, {
        method: 'PUT',
        body: JSON.stringify({
          isAchieved: true,
          achievedDate: new Date().toISOString(),
          status: 'Achieved'
        })
      })

      if (response.success) {
        // Update local state
        setProjects(prevProjects => 
          prevProjects.map(project => ({
            ...project,
            milestones: project.milestones.map(milestone => 
              milestone._id === milestoneId || milestone.id === milestoneId
                ? { 
                    ...milestone, 
                    status: 'Achieved' as const, 
                    isAchieved: true,
                    achievedDate: new Date().toISOString()
                  }
                : milestone
            )
          }))
        )

        if (selectedProject) {
          setSelectedProject(prev => prev ? ({
            ...prev,
            milestones: prev.milestones.map(milestone => 
              milestone._id === milestoneId || milestone.id === milestoneId
                ? { 
                    ...milestone, 
                    status: 'Achieved' as const, 
                    isAchieved: true,
                    achievedDate: new Date().toISOString()
                  }
                : milestone
            )
          }) : null)
        }

        console.log("Milestone marked as achieved successfully")
      }
    } catch (error) {
      console.error("Error marking milestone as achieved:", error)
      alert(`Failed to update milestone: ${error instanceof Error ? error.message : "Unknown error"}`)
    } finally {
      setUpdatingMilestone(null)
    }
  }

  // Load project milestones
  const loadProjectMilestones = (project: ProjectWithMilestones) => {
    setSelectedProject(project)
    setShowMilestones(true)
  }

  // Calculate milestone status
  const getMilestoneStatus = (milestone: Milestone) => {
    if (milestone.isAchieved || milestone.status === 'Achieved') {
      return 'Achieved'
    }
    
    const dueDate = new Date(milestone.dueDate)
    const currentDate = new Date()
    
    if (currentDate > dueDate) {
      return 'Overdue'
    }
    
    return 'Pending'
  }

  // Get status color
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Achieved':
        return 'bg-green-100 text-green-800'
      case 'Overdue':
        return 'bg-red-100 text-red-800'
      case 'Pending':
        return 'bg-yellow-100 text-yellow-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  // Load data on component mount
  useEffect(() => {
    const loadData = async () => {
      setLoading(true)
      try {
        await Promise.all([
          fetchDashboardAnalytics(),
          fetchProjectsWithMilestones()
        ])
      } catch (error) {
        console.error("Error loading dashboard data:", error)
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [])

  // Prepare chart data
  const revenueChartData = {
    labels: revenueData.map(item => item.month),
    datasets: [
      {
        label: "Revenue",
        data: revenueData.map(item => item.revenue),
        borderColor: "rgb(59, 130, 246)",
        backgroundColor: "rgba(59, 130, 246, 0.1)",
        tension: 0.4,
      },
      {
        label: "Expenses",
        data: revenueData.map(item => item.expenses),
        borderColor: "rgb(239, 68, 68)",
        backgroundColor: "rgba(239, 68, 68, 0.1)",
        tension: 0.4,
      },
    ],
  }

  const expenseChartData = {
    labels: expenseData.map(item => item.category),
    datasets: [
      {
        label: "Expenses",
        data: expenseData.map(item => item.amount),
        backgroundColor: [
          "rgba(239, 68, 68, 0.8)",
          "rgba(245, 158, 11, 0.8)",
          "rgba(34, 197, 94, 0.8)",
          "rgba(168, 85, 247, 0.8)",
          "rgba(107, 114, 128, 0.8)",
        ],
      },
    ],
  }

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: "top" as const,
      },
    },
  }

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="bg-gray-200 rounded-lg h-24"></div>
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-gray-200 rounded-lg h-64"></div>
          <div className="bg-gray-200 rounded-lg h-64"></div>
        </div>
        <div className="bg-gray-200 rounded-lg h-96"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-2 bg-blue-100 rounded-lg">
              <span className="text-2xl">👥</span>
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Clients</p>
              <p className="text-2xl font-semibold text-gray-900">{stats.totalClients}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-2 bg-green-100 rounded-lg">
              <span className="text-2xl">✅</span>
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Active Clients</p>
              <p className="text-2xl font-semibold text-gray-900">{stats.activeClients}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-2 bg-emerald-100 rounded-lg">
              <span className="text-2xl">💰</span>
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Revenue</p>
              <p className="text-2xl font-semibold text-gray-900">${stats.totalRevenue.toLocaleString()}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-2 bg-purple-100 rounded-lg">
              <span className="text-2xl">📊</span>
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Active Projects</p>
              <p className="text-2xl font-semibold text-gray-900">{stats.activeProjects}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Revenue & Expenses Over Time</h3>
          <Line data={revenueChartData} options={chartOptions} />
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Expense Breakdown</h3>
          <Bar data={expenseChartData} options={chartOptions} />
        </div>
      </div>

      {/* Active Projects with Milestones */}
      <div className="bg-white rounded-lg shadow">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Active Projects with Milestones</h3>
          <p className="text-sm text-gray-600 mt-1">Projects currently in progress with milestone tracking</p>
        </div>

        {projects.length === 0 ? (
          <div className="p-6 text-center text-gray-500">
            No active projects with milestones found.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Project Details
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Client
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Total Value
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Timeline
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Progress
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {projects.map((project) => {
                  const achievedMilestones = project.milestones.filter(m => 
                    m.isAchieved || m.status === 'Achieved'
                  ).length
                  const totalMilestones = project.milestones.length
                  const progressPercentage = totalMilestones > 0 ? 
                    (achievedMilestones / totalMilestones) * 100 : 0

                  return (
                    <tr key={project._id || project.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div>
                          <div className="text-sm font-medium text-gray-900">{project.name}</div>
                          <div className="text-sm text-gray-500 truncate max-w-xs">{project.description}</div>
                          {project.estimateName && (
                            <div className="text-xs text-blue-600">{project.estimateName}</div>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {project.clientName}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ${project.totalAmount.toLocaleString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <div>
                          <div>Start: {new Date(project.startDate).toLocaleDateString()}</div>
                          <div>End: {new Date(project.endDate).toLocaleDateString()}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-1">
                            <div className="flex items-center justify-between text-xs mb-1">
                              <span className="text-gray-600">{achievedMilestones}/{totalMilestones} milestones</span>
                              <span className="text-gray-600">{Math.round(progressPercentage)}%</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div
                                className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                                style={{ width: `${progressPercentage}%` }}
                              ></div>
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <button
                          onClick={() => loadProjectMilestones(project)}
                          className="text-blue-600 hover:text-blue-900"
                        >
                          View Milestones
                        </button>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Milestone Details Modal */}
      {showMilestones && selectedProject && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-11/12 max-w-4xl shadow-lg rounded-md bg-white">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-gray-900">
                Milestones for {selectedProject.name}
              </h3>
              <button
                onClick={() => setShowMilestones(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <span className="sr-only">Close</span>
                <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <div className="bg-gray-50 rounded-lg p-4 mb-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="font-medium">Client:</span> {selectedProject.clientName}
                </div>
                <div>
                  <span className="font-medium">Total Value:</span> ${selectedProject.totalAmount.toLocaleString()}
                </div>
                <div>
                  <span className="font-medium">Timeline:</span> {new Date(selectedProject.startDate).toLocaleDateString()} - {new Date(selectedProject.endDate).toLocaleDateString()}
                </div>
              </div>
            </div>

            <div className="space-y-4 max-h-96 overflow-y-auto">
              {selectedProject.milestones
                .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
                .map((milestone) => {
                  const status = getMilestoneStatus(milestone)
                  const isUpdating = updatingMilestone === (milestone._id || milestone.id)

                  return (
                    <div key={milestone._id || milestone.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex justify-between items-start mb-3">
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900">{milestone.name}</h4>
                          <p className="text-sm text-gray-600 mt-1">{milestone.description}</p>
                        </div>
                        <div className="text-right ml-4">
                          <p className="text-lg font-semibold text-gray-900">${milestone.amount.toLocaleString()}</p>
                          <p className="text-sm text-gray-500">{milestone.percentage}%</p>
                        </div>
                      </div>

                      <div className="flex justify-between items-center">
                        <div className="flex items-center space-x-4">
                          <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(status)}`}>
                            {status}
                          </span>
                          <span className="text-sm text-gray-500">
                            Due: {new Date(milestone.dueDate).toLocaleDateString()}
                          </span>
                          {milestone.achievedDate && (
                            <span className="text-sm text-green-600">
                              Achieved: {new Date(milestone.achievedDate).toLocaleDateString()}
                            </span>
                          )}
                        </div>

                        {status !== 'Achieved' && (
                          <button
                            onClick={() => markMilestoneAsAchieved(milestone._id || milestone.id!)}
                            disabled={isUpdating}
                            className="px-3 py-1 bg-green-600 text-white text-sm rounded-md hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
                          >
                            {isUpdating && (
                              <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white mr-1"></div>
                            )}
                            {isUpdating ? "Updating..." : "Mark Achieved"}
                          </button>
                        )}
                      </div>
                    </div>
                  )
                })}
            </div>

            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setShowMilestones(false)}
                className="px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}