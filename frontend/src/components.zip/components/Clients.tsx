"use client"

import React, { useState, useEffect } from "react";
import { 
  Table, Button, Input, Select, Modal, Form, Tag, notification, Empty, Space, Spin,
  Card, Row, Col, Statistic, Avatar, Divider, List, Badge, Tooltip, Skeleton
} from "antd";
import type { ColumnsType } from "antd/es/table";
import { 
  ExportOutlined, PlusOutlined, EditOutlined, DeleteOutlined, EyeOutlined,
  UserOutlined, ProjectOutlined, DollarOutlined, TrophyOutlined,
  PhoneOutlined, MailOutlined, BankOutlined, CalendarOutlined,
  CheckCircleOutlined, ClockCircleOutlined, ExclamationCircleOutlined
} from "@ant-design/icons";
import Cookies from "js-cookie";

const { Search } = Input;
const { Option } = Select;
const { TextArea } = Input;

interface Project {
  id: number;
  name: string;
  description: string;
  status: "Active" | "Completed" | "On Hold" | "Cancelled";
  createdAt: string;
  clientId?: number;
}

interface Client {
  id: number;
  name: string;
  email: string;
  phone: string;
  company: string;
  projects: number;
  status: "Active" | "Inactive";
  notes: string;
  projectsList?: Project[];
}

const API_URL = "http://localhost:5000/api/clients";

export default function ClientManagement() {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [isClientDetailVisible, setIsClientDetailVisible] = useState(false);
  const [isProjectModalVisible, setIsProjectModalVisible] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [deleteLoading, setDeleteLoading] = useState<number | null>(null);
  const [projectSubmitLoading, setProjectSubmitLoading] = useState(false);
  const [form] = Form.useForm();
  const [projectForm] = Form.useForm();
  const [api, contextHolder] = notification.useNotification();

  // Helper to safely get clients array
  const getSafeClients = () => Array.isArray(clients) ? clients : [];

  // Get JWT token from cookies
  const getAuthToken = () => {
    const token = Cookies.get("jwt_token");
    if (!token) {
      showNotification("error", "Authentication Error", "Please login to continue");
      throw new Error("No JWT token found");
    }
    return token;
  };

  // Authorized fetch wrapper
  const authFetch = async (url: string, options: RequestInit = {}) => {
    const token = getAuthToken();
    try {
      const response = await fetch(url, {
        ...options,
        headers: {
          ...options.headers,
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `HTTP ${response.status}: ${response.statusText}`);
      }
      return await response.json();
    } catch (error) {
      if (error instanceof TypeError && error.message.includes('fetch')) {
        throw new Error("Network error: Unable to connect to server");
      }
      throw error;
    }
  };

  // Fetch clients from API
  const fetchClients = async () => {
    setLoading(true);
    try {
      const data = await authFetch(API_URL + "/get-all-clients");
      const enrichedData = Array.isArray(data) ? data.map(client => ({
        ...client,
        projectsList: client.projectsList || []
      })) : [];
      setClients(enrichedData);
    } catch (error) {
      console.error("Failed to fetch clients:", error);
      showNotification("error", "Error", error instanceof Error ? error.message : "Failed to fetch clients");
      setClients([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchClients();
  }, []);

  // Calculate statistics
  const stats = React.useMemo(() => {
    const safeClients = getSafeClients();
    const activeClients = safeClients.filter(c => c.status === "Active").length;
    const totalProjects = safeClients.reduce((sum, c) => sum + (c.projects || 0), 0);
    
    return {
      totalClients: safeClients.length,
      activeClients,
      totalProjects
    };
  }, [clients]);

  // Filter clients based on search and status
  const filteredClients = React.useMemo(() => {
    const safeClients = getSafeClients();
    return safeClients.filter(client => {
      if (!client) return false;
      
      const searchLower = searchTerm.toLowerCase();
      const matchesSearch = 
        client.name?.toLowerCase().includes(searchLower) ||
        client.email?.toLowerCase().includes(searchLower) ||
        client.company?.toLowerCase().includes(searchLower);
      
      const matchesStatus = statusFilter === "All" || client.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [clients, searchTerm, statusFilter]);

  // Show notification
  const showNotification = (type: "success" | "error" | "info" | "warning", message: string, description: string) => {
    api[type]({ message, description, placement: "topRight" });
  };

  // Handle form submission
  const handleSubmit = async (values: Omit<Client, "id" | "projects">) => {
    try {
      if (editingClient) {
        await authFetch(`${API_URL}/update-client/${editingClient.id}`, {
          method: "PUT",
          body: JSON.stringify(values),
        });
        setClients(prevClients => prevClients.map(c => 
          c.id === editingClient.id ? {...c, ...values} : c
        ));
        showNotification("success", "Success", "Client updated successfully");
      } else {
        const newClient = await authFetch(API_URL + "/create-client", {
          method: "POST",
          body: JSON.stringify({...values, projects: 0}),
        });
        setClients(prevClients => [...prevClients, {
          ...newClient,
          projectsList: []
        }]);
        showNotification("success", "Success", "Client added successfully");
      }
      
      setIsModalVisible(false);
      setEditingClient(null);
      form.resetFields();
    } catch (error) {
      console.error("Operation failed:", error);
      showNotification("error", "Error", error instanceof Error ? error.message : "Operation failed");
    }
  };

  // Handle project submission - FIXED
  const handleProjectSubmit = async (values: Omit<Project, "id" | "createdAt">) => {
    if (!selectedClient) {
      showNotification("error", "Error", "No client selected");
      return;
    }

    setProjectSubmitLoading(true);
    try {
      // Prepare project data for backend
      const projectData = {
        title: values.name,
        description: values.description,
        status: values.status,
        clientId: selectedClient.id
      };

      // Make API call to create project
      const newProject = await authFetch(`${API_URL}/create-project/${selectedClient.id}`, {
        method: "POST",
        body: JSON.stringify(projectData),
      });
       const updateProject = {
        name:newProject.data.name,
        description:newProject.data.description,
        status:newProject.data.status,
       }
       console.log("New project created:", updateProject);
      // Update local state with the new project
      const updatedClients = clients.map(c => {
        if (c.id === selectedClient.id) {
          return {
            ...c,
            projects: c.projects + 1,
            projectsList: [...(c.projectsList || []), {
              ...updateProject,
              createdAt: newProject.createdAt || new Date().toISOString().split('T')[0]
            }]
          };
        }
        return c;
      });
      
      setClients(updatedClients);
      
      // Update selected client for the detail view
      const updatedSelectedClient = {
        ...selectedClient,
        projects: selectedClient.projects + 1,
        projectsList: [...(selectedClient.projectsList || []), {
          ...newProject,
          createdAt: newProject.createdAt || new Date().toISOString().split('T')[0]
        }]
      };
      setSelectedClient(updatedSelectedClient);
      
      showNotification("success", "Success", "Project added successfully");
      setIsProjectModalVisible(false);
      projectForm.resetFields();
    } catch (error) {
      console.error("Project creation failed:", error);
      showNotification("error", "Error", error instanceof Error ? error.message : "Failed to create project");
    } finally {
      setProjectSubmitLoading(false);
    }
  };

  // Handle client deletion
  const handleDelete = async (id: number) => {
    setDeleteLoading(id);
    try {
      await authFetch(`${API_URL}/delete-client/${id}`, { 
        method: "DELETE" 
      });
      
      setClients(prevClients => prevClients.filter(c => c.id !== id));
      showNotification("success", "Success", "Client deleted successfully");
      
      // Close detail modal if the deleted client was being viewed
      if (selectedClient?.id === id) {
        setIsClientDetailVisible(false);
        setSelectedClient(null);
      }
    } catch (error) {
      console.error("Delete failed:", error);
      showNotification("error", "Error", error instanceof Error ? error.message : "Failed to delete client");
    } finally {
      setDeleteLoading(null);
    }
  };

  // View client details
  const viewClientDetails = (client: Client) => {
    
    fetchClientProjects(client.id,client
    
    )
    setIsClientDetailVisible(true);
  };

  // Export to CSV
  const exportToCSV = () => {
    if (filteredClients.length === 0) {
      showNotification("warning", "No Data", "There are no clients to export");
      return;
    }

    const headers = ["Name", "Email", "Phone", "Company", "Projects", "Status", "Notes"];
    const csvContent = [
      headers.join(","),
      ...filteredClients.map(client => 
        [
          client.name, 
          client.email, 
          client.phone, 
          client.company, 
          client.projects, 
          client.status, 
          client.notes
        ]
          .map(field => `"${field?.toString().replace(/"/g, '""')}"`)
          .join(",")
      ),
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `clients_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Get status icon
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "active": return <CheckCircleOutlined style={{ color: "#34d399" }} />;
      case "Completed": return <TrophyOutlined style={{ color: "#3b82f6" }} />;
      case "On Hold": return <ClockCircleOutlined style={{ color: "#f59e0b" }} />;
      case "Cancelled": return <ExclamationCircleOutlined style={{ color: "#ef4444" }} />;
      default: return null;
    }
  };
  const deleteProject = async(projectid) =>{
    try {
      // Call API to delete the project
      await authFetch(`${API_URL}/delete-project/${projectid}`, {
      method: "DELETE",
      });

      // Update selectedClient state
      if (selectedClient) {
      const updatedProjects = (selectedClient.projectsList || []).filter(
        (project) => project.id !== projectid
      );
      setSelectedClient({
        ...selectedClient,
        projects: updatedProjects.length,
        projectsList: updatedProjects,
      });
      }

      // Update clients state
      setClients((prevClients) =>
      prevClients.map((client) =>
        client.id === selectedClient?.id
        ? {
          ...client,
          projects: (client.projectsList?.length || 0) - 1,
          projectsList: (client.projectsList || []).filter(
            (project) => project.id !== projectid
          ),
          }
        : client
      )
      );

      showNotification("success", "Success", "Project deleted successfully");
    } catch (error) {
      console.error("Failed to delete project:", error);
      showNotification(
      "error",
      "Error",
      error instanceof Error ? error.message : "Failed to delete project"
      );
    }
  }
  // Table columns - Enhanced for responsiveness
  const columns: ColumnsType<Client> = [
    {
      title: "Client",
      dataIndex: "name",
      key: "name",
      fixed: 'left',
      width: 250,
      render: (text, record) => (
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-blue-100 rounded-lg flex-shrink-0">
            <span className="text-xl">👤</span>
          </div>
          <div className="min-w-0 flex-1">
            <div className="font-semibold text-gray-900 truncate">{text}</div>
            <div className="text-sm text-gray-500 truncate">{record.company}</div>
          </div>
        </div>
      ),
      sorter: (a, b) => a.name.localeCompare(b.name),
    },
    {
      title: "Contact",
      children: [
        {
          title: "Email",
          dataIndex: "email",
          key: "email",
          width: 200,
          render: email => (
            <a 
              href={`mailto:${email}`} 
              className="text-blue-600 hover:text-blue-800 text-sm block truncate"
              title={email}
            >
              {email}
            </a>
          ),
        },
        {
          title: "Phone",
          dataIndex: "phone",
          key: "phone",
          width: 150,
          render: phone => (
            <a 
              href={`tel:${phone}`} 
              className="text-gray-600 hover:text-gray-800 text-sm block truncate"
              title={phone}
            >
              {phone}
            </a>
          ),
        },
      ],
    },
    {
      title: "Projects",
      dataIndex: "projects",
      key: "projects",
      width: 100,
      render: projects => (
        <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
          {projects}
        </span>
      ),
      sorter: (a, b) => a.projects - b.projects,
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      width: 120,
      render: status => (
        <span
          className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
            status === "Active"
              ? "bg-green-100 text-green-800"
              : "bg-gray-100 text-gray-800"
          }`}
        >
          {status}
        </span>
      ),
      filters: [
        { text: "Active", value: "Active" },
        { text: "Inactive", value: "Inactive" },
      ],
      onFilter: (value, record) => record.status === value,
    },
    {
      title: "Actions",
      key: "actions",
      fixed: 'right',
      width: 200,
      render: (_, record) => (
        <Space size="small" wrap>
          <Button 
            size="small"
            icon={<EyeOutlined />} 
            onClick={() => viewClientDetails(record)}
            className="text-blue-600 border-blue-600 hover:bg-blue-50"
          >
            View
          </Button>
          <Button 
            size="small"
            icon={<EditOutlined />} 
            onClick={() => {
              setEditingClient(record);
              form.setFieldsValue(record);
              setIsModalVisible(true);
            }}
            className="text-orange-600 border-orange-600 hover:bg-orange-50"
          >
            Edit
          </Button>
          <Button 
            size="small"
            icon={<DeleteOutlined />} 
            onClick={() => handleDelete(record.id)} 
            danger
            loading={deleteLoading === record.id}
            className="hover:bg-red-50"
          >
            Delete
          </Button>
        </Space>
      ),
    },
  ];
  const fetchClientProjects = async (clientId: number,currClient ) => {
  
    try {
      const projects = await authFetch(`${API_URL}/get-client-projects/${clientId}`);
      console.log(projects.data,currClient)
      const data = projects.data;
      // Update the selected client with fetched projects
      console.log(selectedClient)
      const updatedSelectedClient = {
        ...currClient,
        projectsList: Array.isArray(data) ? data : []
      };
      setSelectedClient(updatedSelectedClient);
      
      // Also update the client in the main clients array
      setClients(prevClients => prevClients.map(client => 
        client.id === clientId 
          ? { ...client, projectsList: Array.isArray(data) ? data : [] }
          : client
      ));
      
    } catch (error) {
      console.error("Failed to fetch client projects:", error);
      showNotification("error", "Error", error instanceof Error ? error.message : "Failed to fetch projects");
      
      // Set empty projects list on error
      if (selectedClient) {
        setSelectedClient({
          ...selectedClient,
          projectsList: []
        });
      }
    } 
  };
  // Loading skeleton
  const LoadingSkeleton = () => (
    <div className="space-y-6">
      {/* Stats Cards Skeleton */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6">
        {[1, 2, 3].map(i => (
          <Card key={i} className="shadow">
            <Skeleton active paragraph={{ rows: 1 }} />
          </Card>
        ))}
      </div>
      
      {/* Filters Skeleton */}
      <Card className="shadow">
        <Skeleton active paragraph={{ rows: 2 }} />
      </Card>
      
      {/* Table Skeleton */}
      <Card className="shadow">
        <Skeleton active paragraph={{ rows: 8 }} />
      </Card>
    </div>
  );

  if (loading) {
    return (
      <div className="p-4 lg:p-6 space-y-6">
        {contextHolder}
        <LoadingSkeleton />
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-6 space-y-6">
      {contextHolder}
      
      {/* Header */}
      <div className="flex flex-col space-y-4 lg:space-y-0 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-2">Client Management</h1>
          <p className="text-gray-600 text-sm lg:text-base">Manage your clients and track their projects efficiently</p>
        </div>
        <Space wrap>
          <Button
            icon={<ExportOutlined />}
            onClick={exportToCSV}
            disabled={filteredClients.length === 0}
            className="hover:bg-blue-50 border-blue-500 text-blue-500"
          >
            <span className="hidden sm:inline">Export CSV</span>
          </Button>
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={() => setIsModalVisible(true)}
            className="bg-blue-600 hover:bg-blue-700 border-blue-600"
          >
            <span className="hidden sm:inline">Add Client</span>
          </Button>
        </Space>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6">
        <div className="bg-white rounded-lg shadow p-4 lg:p-6">
          <div className="flex items-center">
            <div className="p-2 bg-blue-100 rounded-lg flex-shrink-0">
              <span className="text-xl lg:text-2xl">👥</span>
            </div>
            <div className="ml-3 lg:ml-4 min-w-0 flex-1">
              <p className="text-xs lg:text-sm font-medium text-gray-600">Total Clients</p>
              <p className="text-xl lg:text-2xl font-semibold text-gray-900">{stats.totalClients}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-4 lg:p-6">
          <div className="flex items-center">
            <div className="p-2 bg-green-100 rounded-lg flex-shrink-0">
              <span className="text-xl lg:text-2xl">✅</span>
            </div>
            <div className="ml-3 lg:ml-4 min-w-0 flex-1">
              <p className="text-xs lg:text-sm font-medium text-gray-600">Active Clients</p>
              <p className="text-xl lg:text-2xl font-semibold text-gray-900">{stats.activeClients}</p>
            </div>
          </div>
        </div>


      </div>
      
      {/* Filters */}
      <div className="bg-white rounded-lg shadow p-4 lg:p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-1">
            <label className="block text-sm font-medium text-gray-700 mb-2">Search</label>
            <Search
              placeholder="Search clients..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              allowClear
              enterButton
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
            <Select
              value={statusFilter}
              onChange={setStatusFilter}
              className="w-full"
            >
              <Option value="All">All Status</Option>
              <Option value="Active">Active</Option>
              <Option value="Inactive">Inactive</Option>
            </Select>
          </div>
          <div className="flex items-end">
            <div className="text-sm text-gray-600 bg-gray-100 px-3 py-2 rounded w-full text-center md:text-left">
              Showing {filteredClients.length} of {clients.length} clients
            </div>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="overflow-x-auto">
          <Table
            columns={columns}
            dataSource={filteredClients}
            rowKey="id"
            scroll={{ x: 'max-content' }}
            pagination={{ 
              pageSize: 10,
              showSizeChanger: true,
              pageSizeOptions: ["10", "20", "50", "100"],
              showQuickJumper: true,
              showTotal: (total, range) => `${range[0]}-${range[1]} of ${total} clients`,
              responsive: true
            }}
            locale={{
              emptyText: (
                <Empty
                  image={Empty.PRESENTED_IMAGE_SIMPLE}
                  description={
                    <span>
                      No clients found. <a onClick={() => setIsModalVisible(true)} className="text-blue-500 hover:text-blue-700 cursor-pointer">Add your first client</a>
                    </span>
                  }
                />
              )
            }}
          />
        </div>
      </div>

      {/* Add/Edit Client Modal */}
      <Modal
        title={
          <div className="flex items-center space-x-2">
            <UserOutlined className="text-blue-500" />
            <span>{editingClient ? "Edit Client" : "Add New Client"}</span>
          </div>
        }
        open={isModalVisible}
        onCancel={() => {
          setIsModalVisible(false);
          setEditingClient(null);
          form.resetFields();
        }}
        footer={null}
        destroyOnClose
        width="100%"
        style={{ maxWidth: 800, top: 20 }}
      >
        <Form
          form={form}
          layout="vertical"
          onFinish={handleSubmit}
          initialValues={{ status: "Active" }}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Form.Item
              label="Full Name"
              name="name"
              rules={[{ required: true, message: "Please enter client name" }]}
            >
              <Input placeholder="John Smith" />
            </Form.Item>

            <Form.Item
              label="Email"
              name="email"
              rules={[
                { required: true, message: "Please enter email" },
                { type: "email", message: "Please enter valid email" }
              ]}
            >
              <Input placeholder="john@example.com" />
            </Form.Item>

            <Form.Item
              label="Phone"
              name="phone"
              rules={[{ pattern: /^[\d\s\+\-\(\)]+$/, message: "Please enter valid phone number" }]}
            >
              <Input placeholder="+1 (555) 123-4567" />
            </Form.Item>

            <Form.Item
              label="Company"
              name="company"
            >
              <Input placeholder="Acme Inc" />
            </Form.Item>
          </div>

          <Form.Item
            label="Status"
            name="status"
          >
            <Select>
              <Option value="Active">Active</Option>
              <Option value="Inactive">Inactive</Option>
            </Select>
          </Form.Item>

          <Form.Item
            label="Notes"
            name="notes"
          >
            <TextArea rows={3} placeholder="Additional information about the client" />
          </Form.Item>

          <div className="flex flex-col-reverse sm:flex-row justify-end gap-3 pt-4">
            <Button 
              onClick={() => {
                setIsModalVisible(false);
                setEditingClient(null);
                form.resetFields();
              }}
              className="w-full sm:w-auto"
            >
              Cancel
            </Button>
            <Button 
              type="primary" 
              htmlType="submit" 
              className="bg-blue-600 hover:bg-blue-700 w-full sm:w-auto"
            >
              {editingClient ? "Update Client" : "Add Client"}
            </Button>
          </div>
        </Form>
      </Modal>

      {/* Client Details Modal */}
      <Modal
        title={
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-100 rounded-lg flex-shrink-0">
              <span className="text-xl">👤</span>
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-lg font-semibold truncate">{selectedClient?.name}</div>
              <div className="text-sm text-gray-500 truncate">{selectedClient?.company}</div>
            </div>
          </div>
        }
        open={isClientDetailVisible}
        onCancel={() => {
          setIsClientDetailVisible(false);
          setSelectedClient(null);
        }}
        footer={[
          <Button key="close" onClick={() => setIsClientDetailVisible(false)} className="w-full sm:w-auto">
            Close
          </Button>,
          <Button 
            key="add-project" 
            type="primary" 
            icon={<PlusOutlined />}
            onClick={() => setIsProjectModalVisible(true)}
            className="bg-green-600 hover:bg-green-700 w-full sm:w-auto"
          >
            Add Project
          </Button>
        ]}
        width="100%"
        style={{ maxWidth: 900, top: 20 }}
      >
        {selectedClient && (
          <div className="space-y-6">
            {/* Client Info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 lg:gap-6">
              <div className="bg-white rounded-lg border p-4 lg:p-6 text-center">
                <div className="text-2xl font-semibold text-gray-900">{selectedClient?.projectsList?.length}</div>
                <div className="text-sm text-gray-600">Total Projects</div>
              </div>
              <div className="bg-white rounded-lg border p-4 lg:p-6 text-center">
                <span
                  className={`inline-flex px-3 py-1 text-sm font-semibold rounded-full ${
                    selectedClient.status === "Active" 
                      ? "bg-green-100 text-green-800" 
                      : "bg-gray-100 text-gray-800"
                  }`}
                >
                  {selectedClient.status}
                </span>
                <div className="text-sm text-gray-600 mt-1">Status</div>
              </div>
            </div>

            {/* Contact Information */}
            <div className="bg-white rounded-lg border p-4 lg:p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Contact Information</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="min-w-0">
                  <div className="text-sm text-gray-600">Email</div>
                  <a href={`mailto:${selectedClient.email}`} className="text-blue-600 hover:text-blue-800 truncate block">
                    {selectedClient.email}
                  </a>
                </div>
                <div className="min-w-0">
                  <div className="text-sm text-gray-600">Phone</div>
                  <a href={`tel:${selectedClient.phone}`} className="text-gray-900 truncate block">
                    {selectedClient.phone}
                  </a>
                </div>
                <div className="min-w-0 sm:col-span-2">
                  <div className="text-sm text-gray-600">Company</div>
                  <div className="text-gray-900 truncate">{selectedClient.company}</div>
                </div>
              </div>
              {selectedClient.notes && (
                <div className="mt-4 pt-4 border-t">
                  <div className="text-sm text-gray-600">Notes</div>
                  <p className="text-gray-900 mt-1 break-words">{selectedClient.notes}</p>
                </div>
              )}
            </div>

            {/* Projects List */}
           {/* Projects List - Continuation */}
            <div className="bg-white rounded-lg border p-4 lg:p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Projects</h3>
              <List
              
                dataSource={selectedClient.projectsList || []}
                renderItem={(project) => (
                  <List.Item className="border rounded-lg mb-2 p-4">
                    
                    <List.Item.Meta
                    
                      avatar={getStatusIcon(project.status)}
                      title={
                        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
                          
                          <span className="font-semibold break-words">{project.name}</span>
                          
                          <span
                            className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full self-start sm:self-auto ${
                              project.status === "Active" ? "bg-green-100 text-green-800" :
                              project.status === "Completed" ? "bg-blue-100 text-blue-800" :
                              project.status === "On Hold" ? "bg-yellow-100 text-yellow-800" : 
                              "bg-red-100 text-red-800"
                            }`}
                          >
                            {project.status}
                            
                          </span>
                          
                        </div>
                      }
                      
                      description={
                        <div>
                          
                          <p className="mb-2 break-words">{project.description}</p>
                          <span className="text-sm text-gray-500">Created: {project.createdAt.slice(0,10)}....</span>
                           <div className="ml24"><Button 
            size="small"
            icon={<DeleteOutlined />} 
            onClick={() => deleteProject(project.id)} 
            danger
            className="hover:bg-red-50"
          >
            Delete
          </Button></div>
                        </div>
                      }
                    />
                  </List.Item>
                )}
                locale={{
                  emptyText: <Empty description="No projects yet" />
                }}
              />
            </div>
          </div>
        )}
      </Modal>

      {/* Add Project Modal */}
      <Modal
        title={
          <div className="flex items-center space-x-2">
            <ProjectOutlined className="text-green-500" />
            <span>Add Project for {selectedClient?.name}</span>
          </div>
        }
        open={isProjectModalVisible}
        onCancel={() => {
          setIsProjectModalVisible(false);
          projectForm.resetFields();
        }}
        footer={null}
        destroyOnClose
        width="100%"
        style={{ maxWidth: 600, top: 20 }}
      >
        <Form
          form={projectForm}
          layout="vertical"
          onFinish={handleProjectSubmit}
          initialValues={{ status: "Active" }}
        >
          <Form.Item
            label="Project Title"
            name="name"
            rules={[{ required: true, message: "Please enter project title" }]}
          >
            <Input placeholder="Website Redesign" />
          </Form.Item>

          <Form.Item
            label="Description"
            name="description"
            rules={[{ required: true, message: "Please enter project description" }]}
          >
            <TextArea rows={3} placeholder="Detailed description of the project" />
          </Form.Item>

          <Form.Item
            label="Status"
            name="status"
          >
            <Select>
              <Option value="Active">Active</Option>
              <Option value="On Hold">On Hold</Option>
              <Option value="Completed">Completed</Option>
              <Option value="Cancelled">Cancelled</Option>
            </Select>
          </Form.Item>

          <div className="flex flex-col-reverse sm:flex-row justify-end gap-3 pt-4">
            <Button 
              onClick={() => {
                setIsProjectModalVisible(false);
                projectForm.resetFields();
              }}
              className="w-full sm:w-auto"
            >
              Cancel
            </Button>
            <Button 
              type="primary" 
              htmlType="submit" 
              loading={projectSubmitLoading}
              className="bg-green-600 hover:bg-green-700 border-green-600 w-full sm:w-auto"
            >
              Add Project
            </Button>
          </div>
        </Form>
      </Modal>
    </div>
  );
}