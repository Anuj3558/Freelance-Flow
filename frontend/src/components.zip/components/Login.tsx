"use client"

import React, { useEffect } from "react"
import { useState } from "react"
import { notification } from "antd"
import Cookies from "js-cookie"
import type { NotificationPlacement } from "antd/es/notification/interface"
import { useUser } from "../UserContext"
interface LoginProps {
  onLogin: (user: { name: string; email: string }) => void
}

export default function Login({ onLogin }: LoginProps) {
  const verifyToken=async () =>{
if(Cookies.get('jwt_token')) {
      // Automatically log in if JWT token exists
      await fetch(`http://localhost:5000/api/auth/verify-token`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${Cookies.get('jwt_token')}`
        }
      })
      .then(response => response.json())
      .then(data => {
        
        if (data.user) {
           openNotification(
        'topRight',
        isLogin ? 'Login Successful' : 'Account Created',
        isLogin ? 'Welcome back!' : 'Your account has been created successfully',
        'success'
      )
          onLogin({
            name: data.user.name || "User",
            email: data.user.email || "",
          })
        }
      })
      .catch(error => {
        openNotification(
        'topRight',
        'Authentication Error',
        error.message || 'Something went wrong',
        'error'
      )
        console.error("Error verifying token:", error)
      })
    }
  }
  useEffect(() => {
    verifyToken();
  }, [verifyToken])
  const [isLogin, setIsLogin] = useState(true)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  })
  const [loading, setLoading] = useState(false)
  const [api, contextHolder] = notification.useNotification()

  const openNotification = (placement: NotificationPlacement, message: string, description: string, type: 'success' | 'error') => {
    const config = {
      message,
      description,
      placement,
    }
    
    if (type === 'success') {
      api.success(config)
    } else {
      api.error(config)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      if (!isLogin && formData.password !== formData.confirmPassword) {
        throw new Error("Passwords don't match!")
      }

      const endpoint = isLogin ? 'login' : 'create-account'
      const response = await fetch(`http://localhost:5000/api/auth/${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: formData.email,
          password: formData.password,
          ...(!isLogin && { name: formData.name })
        }),
      })
        
      const data = await response.json()
      Cookies.set('jwt_token', data.token, { 
        expires: 7, // Expires in 7 days
        secure: 'production',
        sameSite: 'strict'
      })
      if (!response.ok) {
        throw new Error(data.message || 'Authentication failed')
      }

      openNotification(
        'topRight',
        isLogin ? 'Login Successful' : 'Account Created',
        isLogin ? 'Welcome back!' : 'Your account has been created successfully',
        'success'
      )

      onLogin({
        name: data.user?.name || formData.name || "User",
        email: formData.email,
      })
    } catch (error: any) {
      openNotification(
        'topRight',
        'Authentication Error',
        error.message || 'Something went wrong',
        'error'
      )
    } finally {
      setLoading(false)
    }
  }

  const demoLogin = async () => {
    try {
      setLoading(true)
      const response = await fetch('http://localhost:5000/api/auth/demo-login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || 'Demo login failed')
      }

      openNotification(
        'topRight',
        'Demo Login Successful',
        'You are now logged in as a demo user',
        'success'
      )

      onLogin({
        name: "Demo User",
        email: "demo@freelanceflow.com",
      })
    } catch (error: any) {
      openNotification(
        'topRight',
        'Demo Login Error',
        error.message || 'Failed to login as demo user',
        'error'
      )
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      {contextHolder}
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-lg w-full space-y-10">
          {/* Header Section */}
          <div className="text-center">
            <div className="mx-auto w-16 h-16 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center shadow-xl shadow-blue-500/25 mb-8">
              <span className="text-white text-2xl font-bold">💼</span>
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent mb-3">
              FreelanceFlow
            </h1>
            <p className="text-lg text-gray-600 font-medium">
              Smart Estimate & Payment Dashboard
            </p>
            <p className="mt-3 text-sm text-gray-500">
              {isLogin ? "Welcome back! Sign in to your account" : "Join thousands of freelancers growing their business"}
            </p>
          </div>

          {/* Login Form */}
          <div className="bg-white/70 backdrop-blur-sm rounded-3xl shadow-2xl shadow-blue-500/10 border border-gray-200/60 p-10">
            <form className="space-y-6" onSubmit={handleSubmit}>
              <div className="space-y-5">
                {!isLogin && (
                  <div>
                    <label htmlFor="name" className="block text-sm font-semibold text-gray-700 mb-2">
                      Full Name
                    </label>
                    <input
                      id="name"
                      name="name"
                      type="text"
                      required={!isLogin}
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-200 placeholder-gray-400 text-gray-900 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-white/80 backdrop-blur-sm shadow-sm hover:shadow-md"
                      placeholder="Enter your full name"
                    />
                  </div>
                )}
                
                <div>
                  <label htmlFor="email" className="block text-sm font-semibold text-gray-700 mb-2">
                    Email Address
                  </label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-200 placeholder-gray-400 text-gray-900 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-white/80 backdrop-blur-sm shadow-sm hover:shadow-md"
                    placeholder="Enter your email address"
                  />
                </div>
                
                <div>
                  <label htmlFor="password" className="block text-sm font-semibold text-gray-700 mb-2">
                    Password
                  </label>
                  <input
                    id="password"
                    name="password"
                    type="password"
                    autoComplete="current-password"
                    required
                    minLength={6}
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-200 placeholder-gray-400 text-gray-900 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-white/80 backdrop-blur-sm shadow-sm hover:shadow-md"
                    placeholder="Enter your password"
                  />
                </div>
                
                {!isLogin && (
                  <div>
                    <label htmlFor="confirmPassword" className="block text-sm font-semibold text-gray-700 mb-2">
                      Confirm Password
                    </label>
                    <input
                      id="confirmPassword"
                      name="confirmPassword"
                      type="password"
                      required={!isLogin}
                      minLength={6}
                      value={formData.confirmPassword}
                      onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-200 placeholder-gray-400 text-gray-900 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-white/80 backdrop-blur-sm shadow-sm hover:shadow-md"
                      placeholder="Confirm your password"
                    />
                  </div>
                )}
              </div>

              {/* Submit Button */}
              <div className="pt-4">
                <button
                  type="submit"
                  disabled={loading}
                  className="group relative w-full flex justify-center py-4 px-6 border border-transparent text-base font-semibold rounded-xl text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-blue-500/25 hover:shadow-xl hover:shadow-blue-500/30 transition-all duration-300 transform hover:-translate-y-0.5"
                >
                  {loading ? (
                    <div className="flex items-center space-x-2">
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      <span>Processing...</span>
                    </div>
                  ) : (
                    <span>{isLogin ? "Sign In" : "Create Account"}</span>
                  )}
                </button>
              </div>

              {/* Footer Links */}
              <div className="flex items-center justify-between pt-6 border-t border-gray-200/60">
                <button
                  type="button"
                  onClick={() => setIsLogin(!isLogin)}
                  className="text-sm font-medium text-blue-600 hover:text-blue-700 transition-colors duration-200"
                >
                  {isLogin ? "Need an account? Sign up" : "Already have an account? Sign in"}
                </button>
                <button 
                  type="button" 
                  onClick={demoLogin}
                  disabled={loading}
                  className="px-4 py-2 text-sm font-medium text-gray-600 hover:text-gray-800 hover:bg-gray-100/80 rounded-lg transition-all duration-200 border border-gray-200 hover:border-gray-300 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Try Demo
                </button>
              </div>
            </form>
          </div>

          {/* Trust Indicators */}
          <div className="text-center space-y-4">
            <p className="text-xs text-gray-500">
              Trusted by 10,000+ freelancers worldwide
            </p>
            <div className="flex justify-center items-center space-x-6 opacity-60">
              <div className="flex items-center space-x-1">
                <span className="text-yellow-400">⭐⭐⭐⭐⭐</span>
                <span className="text-xs text-gray-600">4.9/5</span>
              </div>
              <div className="w-px h-4 bg-gray-300"></div>
              <span className="text-xs text-gray-600">🔒 Secure & Encrypted</span>
              <div className="w-px h-4 bg-gray-300"></div>
              <span className="text-xs text-gray-600">💼 Professional Grade</span>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}